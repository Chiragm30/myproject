package com.appsdeveloperblog.photoapp.api.Gateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CodingTask2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
